from flask import Blueprint

blueprint = Blueprint('function',__name__)

from . import general
from . import sys