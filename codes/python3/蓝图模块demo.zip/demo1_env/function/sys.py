from . import blueprint


@blueprint.route('/sys')
def index_sys():
    return '欢迎使用sys功能'


@blueprint.route('/sys/info')
def info_sys():
    return '你行使的功能为sys功能'