from . import blueprint


@blueprint.route('/general')
def index_general():
    return '欢迎使用general功能'


@blueprint.route('/general/info')
def info_general():
    return '你行使的功能为general功能'