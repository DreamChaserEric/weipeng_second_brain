# from flask import Flask,render_template
# app = Flask(__name__)
# app.debug = True

# @app.route('/<name>/<grade>/')
# def index(name,grade):
#     info = {
#         'name':name,
#         'grade':grade
#     }
#     return render_template('index.html',info=info)

# if __name__ =='__main__':

from flask import Flask
from admin import blueprint as blue_1
from function import blueprint as blue_2


app = Flask(__name__)
app.register_blueprint(blue_1,url_prefix='/admin')
app.register_blueprint(blue_2,url_prefix='/function')

@app.route('/')
def hello_world():
    return '公司系统'


if __name__ == '__main__':
    # app.run()
    app.run('0.0.0.0')

