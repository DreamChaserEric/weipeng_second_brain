from . import blueprint


@blueprint.route('/super')
def index_super():
    return '欢迎登录管理员系统'


@blueprint.route('/super/info')
def info_super():
    return '你的身份为super'