from . import blueprint


@blueprint.route('/user')
def index_user():
    return '欢迎登录用户系统'


@blueprint.route('/user/info')
def info_user():
    return '你的身份为user'