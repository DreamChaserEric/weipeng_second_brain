from flask import Blueprint

blueprint = Blueprint('admin',__name__)

from . import user
from . import super